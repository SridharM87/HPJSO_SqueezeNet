import random,math
import numpy as np
from Proposed_HPJSO import fitness


def optimize(opt_nodes, pop, en, de, x_value, y_value, nc, nodes, bs,error,datapacket):
    def generate(n):   #Generated solution
        data = []
        for i in range(n):
            data.append(random.sample(opt_nodes, nc))  # random nodes to the size of nc
        return data

    N, M, lb, ub = nc, nc, 1, 5
    g, max = 0, 100

    soln = generate(N)


    def opt_current(Iph,Id):
        Io=[]
        for i in range(len(Iph)):
            for j in range(len(Iph[i])):
                Io.append(Iph[i][j]-Id[j])
        return Io

    def reverse_sat_current(Istc):
        Io=[]
        T=100 # Absolute temperature
        q=1.6*(10^-19) # Electron charge
        k=1.38*(10^-23)
        for i in range(len(Istc)):
            Io.append(Istc[i]*(np.square(T/T))*np.exp(q/k))
        return Io

    # check the values in bound
    def check(data):
        c_data = []
        for i in range(len(data)):
            if (data[i] not in c_data) and (data[i] in opt_nodes):  # if node in opt_node but not in c_data

                c_data.append(data[i])  # add node
            else:

                tem = random.choice(opt_nodes)  # select random node

                c_data.append(tem)

        return c_data
    def ocean_current(x):
        Drift=[]
        N=len(x)
        mu=np.mean(x)
        Beta=3  # Distribution coefficient
        ac=5  # Attractive coefficient
        for i in range(len(x)):
            Drift.append((1/N)*np.sum(x[i]-ac))
        Xi=[]
        for j in range(len(x)):
            c=2*random.random()
            z=random.random()
            R=2
            Xi.append((x[j]*(1+c*z*np.cos(2*np.pi*R*4))+(random.uniform(0,1)*x[j]-Beta*random.uniform(0,1)*mu)*(c*z*np.cos(2*np.pi*R*4)))/(c*z*np.cos(2*np.pi*R*4)+1))  # update equation

        latest=check(Xi)

        return latest

    while g<max:
        fit = fitness.func(soln, opt_nodes, en, nodes, bs, x_value, y_value, nc,error,datapacket)

        Op_c=opt_current(soln,fit)

        Ist=reverse_sat_current(Op_c)

        upd_soln=ocean_current(Ist)


        g += 1


    return upd_soln

