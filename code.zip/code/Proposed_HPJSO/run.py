import numpy, random
from Proposed_HPJSO import HPJSO


def func(rounds, nodes, n_cluster, energy, delay, data_pack, x_value, y_value, bs, i, pop, xt, xr, col_n,
         simulation_result, throughput):
    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt((numpy.square(x_value[p2] - x_value[p1])) + (numpy.square(y_value[p2] - y_value[p1])))
        return dist

    # calculate node energy
    def calc_node_en(np, prev_en):

        en = prev_en.copy()  # copy of previous round energy
        x_t,x_r = 0.003,0.003
        m, n = 0.009, 1000  # normalizing factor

        # energy drop for all nodes
        for ed in range(len(np) - 1):
            y = data_pack[np[ed]]  # no. of transmitted bits
            if ed == 0:  # source node
                if en[np[ed]] > 0:
                    dt = distance(np[ed], np[ed + 1]) / n  # distance to send the data
                    E = en[np[ed]] - (x_t * y) * dt  # only send the data to head
                    if E > 0:
                        en[np[ed]] = E
                    else:
                        en[np[ed]] = 0
                else:
                    en[np[ed]] = 0

            else:  # other nodes in path
                if np[ed] > 0:  # if 0 then no path
                    if en[np[ed]] > 0:
                        dt, dr = distance(np[ed], np[ed + 1]) / n, distance(np[ed], np[
                            ed - 1]) / n  # distance to send & receive the data
                        E = en[np[ed]] - (x_r * y) * dr - (x_t * y) * dt  # receive & send
                        if E > 0:
                            en[np[ed]] = E
                        else:
                            en[np[ed]] = 0
                    else:
                        en[np[ed]] = 0
        return en

    # calculate node delay & throughput
    def calc_node_de_tp(en, data):
        de, tp = [], []
        n_packet, packet_received = 0, 0  # total packets, packets received
        for dt in range(len(en)):  # to the size of the node
            r = random.uniform(-1, 1)
            row = numpy.abs(((1.0 - en[dt]) * data[dt]) + r)
            lam = data[dt]
            n_packet = n_packet + data[dt]
            packet_received = packet_received + (en[dt] * data[dt])
            tp.append((en[dt] * data[dt]) / data[dt])
            d = row / lam
            if (d < 1):
                de.append(d)
            else:
                de.append(1)
        return de, tp

    # Group with Cluster Head
    def node_clustering(n, CH):
        clustered = []
        for i in range(n):
            tem = []  # tem array to store the distance value
            for j in range(len(CH)):
                tem.append(
                    distance(i, CH[j]))  # distance calculation between cluster head & nodes except base station
            min_index = numpy.argmin(tem)

            clustered.append(CH[min_index])  # grouped cluster head is added
        clustered.append(bs)  # added base station at last separately
        return clustered

    def CH_selection():

        CH = random.sample(range(0, nodes), n_cluster)  # random cluster Head

        return CH


    def normal_dis(nodes): # normal distribution
        mu, sigma = 0.5, 0.1
        norm = numpy.random.normal(mu, sigma,nodes)
        return norm

    def count(n): # error count
        c = 0
        for i in range(len(n)):
            if n[i] < 0.4:
                c += 1
        return c

    def cal_error(opt_nodes):
        err = [] # error of sensor nodes
        for i in range(nodes):
            norm = normal_dis(nodes)
            error = (count(norm) / (nodes + count(norm)))
            err.append(error)
        T = 0.3 # threshold
        for i in range(len(err)):
            if err[i] > T: # if error of node is high then it is in sleep mode and will not involve in txn
                print("error")
                opt_nodes.remove(i)
        return opt_nodes,err

    # Path detection
    def detection(opt_nodes, base, en, de, pn, n_c, nodes, data_pack,error):

        pth = []
        pth.append(0)  # source
        if (n_c > len(opt_nodes)): n_c = len(opt_nodes)  # non dead nodes

        # Cluster Head selection by Trust_Aware_Routing Protocol
        cluster_head = CH_selection()

        grp = node_clustering(nodes, cluster_head)  # cluster head of the nodes
        # Path detection by Proposed_HPJSO_Squeezenet CIIEHO

        opt_path = HPJSO.optimize(cluster_head, pop, en, de, x_value, y_value, n_cluster, nodes, bs,error,data_pack)


        for op in range(len(opt_path)):
            pth.append(opt_path[op])

        pth.append(base)  # destination
        pth = numpy.unique(pth)
        pth.sort()
        return cluster_head, grp, pth.tolist()

    # nodes other than dead nodes
    def get_active_nodes(en):
        opt_n = []
        for o in range(len(en)):
            if (o > 0) and (en[o] > 0):  # node with energy(not the dead node)
                opt_n.append(o)  # nodes other than source & destination
        return opt_n
    def get_dis(path):
        d = []
        for i in range(len(path)-1):
            dist = numpy.sqrt((numpy.square(x_value[path[i+1]] - x_value[path[i]])) + (numpy.square(y_value[path[i+1]] - y_value[path[i]])))
            d.append(dist)
        return d
    # get non dead nodes
    opt_n = get_active_nodes(energy)
    opt_nodes, error = cal_error(opt_n) # error of sensor nodes, and finding the sleep node
    # Path from source to destination
    round_throughput, round_energy, round_delay = throughput.copy(), energy.copy(), delay.copy()
    if (len(opt_nodes) > 0):
        ch, cluster_group, path = detection(opt_nodes, bs, energy, delay, pop, n_cluster, nodes, data_pack,error)
        round_energy = calc_node_en(path, energy)  # energy of nodes after the transmission
        round_delay, round_throughput = calc_node_de_tp(energy, data_pack)
        round_dis = get_dis(path)
    # results for simulation


    dead_node = []  # nodes with no energy
    for j in range(len(round_energy)):

        if (round_energy[j] == 0):

            dead_node.append(j)

    simulation_result.append(x_value)  # nodes x-axis value
    simulation_result.append(y_value)  # nodes y-axis value
    simulation_result.append(n_cluster)  # no. of cluster heads
    simulation_result.append(i)  # no. of rounds
    simulation_result.append(bs)  # Base station
    simulation_result.append(col_n)  # no. of grid columns in simulation window
    simulation_result.append(ch)  # Cluster head nodes
    simulation_result.append(cluster_group)  # nodes grouped with cluster heads
    simulation_result.append(dead_node)  # dead nodes (nodes with energy 0)
    simulation_result.append(path)  # transmission path of last node

    return round_throughput, round_energy, round_delay, round_dis
