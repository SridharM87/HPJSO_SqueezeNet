import random, numpy as np


# distance between nodes
def distance(p1, p2, x_value, y_value):

    dist = np.sqrt((np.square(x_value[p2] - x_value[p1])) + (np.square(y_value[p2] - y_value[p1])))  # distance formula
    return dist


# Energy calculation
def calc_energy(CH, en, n):
    en_summ = 0
    for i in range(len(CH)):
        en_summ += en[CH[i]]  # energy consumption
    E = 1 / (n) * en_summ
    return E
#Throughput
def cal_throughput(En,data_packet):
    Thr=[]
    for i in range(len(data_packet)):

        Thr.append(np.sum((En*len(data_packet)))/(data_packet[i]))
    ThR_=np.mean(Thr)
    return ThR_


# grouping nodes
def group_nodes(nodes, cg):
    nodes_clustered = []
    for i in range(len(nodes)):
        tem = []
        for j in range(len(cg) - 1):  # -1, since last node is base station
            if (nodes[i] == cg[j]):  # node in that cluster
                tem.append(j)
        nodes_clustered.append(tem)  # group nodes in same cluster
    return nodes_clustered


# Node grouping
def node_clustering(n, CH, bs, xv, yv):
    clustered = []
    for i in range(n):
        tem = []  # tem array to store the distance value
        for j in range(len(CH)):

            tem.append(distance(i, CH[j], xv, yv))  # distance calculation between cluster head & nodes except base station
        min_index = np.argmin(tem)
        clustered.append(CH[min_index])  # grouped cluster head is added
    clustered.append(bs)  # added base station at last separately
    return clustered

def find_error(nodes,err):
    Err = []
    for i in range(len(nodes)):
        Err.append(err[nodes[i]])
    error = np.mean(Err)
    return error

def power(nodes, en):
    En = []
    for i in range(len(nodes)):
        En.append(en[nodes[i]])
    Pm = np.mean(En)  # power -> constant between transmitter and receiver
    return Pm


def dist(nodes, x, y):
    D = []
    for i in range(len(nodes)):
        D.append(distance(i, i + 1, x, y))  # distance between nodes
    Dis = np.mean(D)
    return Dis


# delay calculation
def cal_delay(nodes_ch, n, m):
    s = 0
    for i in range(n):
        s += (len(nodes_ch[i])) / m
    Delay = (1 / n) * s
    return Delay


# Inter cluster distance
def Inter_D(CH, n, x, y):

    F1 = 1000  # Normalizing factor
    summ = 0
    for i in range(n):
        s = 0
        for j in range(n):
            s += distance(CH[i], CH[j], x, y)
        summ += s
    D_inter = (1 / (F1 * n)) * summ
    return D_inter


# Intra cluster distance
def Intra_D(CH, n, m, xv, yv):
    F2 = 1000  # normalizing factor
    summ = 0
    for i in range(m):
        s = 0
        for j in range(n):
            s += distance(i, CH[j], xv, yv)  # distance calculation between cluster head & nodes
        summ += s
    D_intra = (1 / (F2 * m * n)) * summ
    return D_intra


# calculation of Link quality
def Link_quality(nodes, en, x, y):
    Pm = power(nodes, en)
    D = dist(nodes, x, y)
    Lq = Pm / D
    return Lq


# fitness calculation
def func(soln, opt_node, en, nodes, bs, xv, yv, nc,err,datapacket):
    m = len(opt_node)  # Total number of nodes
    n = nc  # Number of cluster heads
    Fit = []
    for i in range(len(soln)):
        grp = node_clustering(nodes, soln[i], bs, xv, yv)  # soln with nodes
        nodes_n_cluster = group_nodes(soln[i], grp)  # group the nodes
        d = cal_delay(nodes_n_cluster, n, m)  # delay
        D_Inter = Inter_D(soln[i], n, xv, yv)  # inter distance
        D_Intra = Intra_D(soln[i], n, m, xv, yv)  # intra distance
        D=D_Intra+D_Inter
        E = calc_energy(soln[i], en, n)  # energy
        LQ = Link_quality(nodes_n_cluster[i], en, xv, yv)  # Link quality
        e = find_error(soln[i],err) # Erroreous value of sensor node
        Th=cal_throughput(E,datapacket)

        F=((1-E)+(1-D)+Th+(1-d)+Th)/5


        Fit.append(F)

    return Fit
