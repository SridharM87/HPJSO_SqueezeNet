from Proposed_HPJSO_Squeezenet.SqueezeNet import Squeeze_Net
import numpy as np
from sklearn.model_selection import train_test_split  # Import train_test_split function
import cv2,keras


def Classify(Seg_Img,target,tr,ACC,SEN):
    array = []
    for i in range(len(Seg_Img)):
        read = cv2.imread(Seg_Img[i])
        array_ = [i for i in range(len(read))]
        array.append(array_)

    X_train, X_test, y_train, y_test = train_test_split(array, target, train_size=tr, random_state=42)


    X_train = np.resize(X_train, (224, 224, 3))
    X_test= np.resize(X_test, (224, 224, 3))
    model = Squeeze_Net(input_shape=(X_train.shape),nb_classes=1)
    X_train = np.resize(X_train, ( 100,224,224,3))
    y_train=np.resize(y_train,(100,1))
    X_test = np.resize(X_test, ( 100,224,224,3))

    model.compile(loss=keras.losses.categorical_crossentropy, optimizer='Adam',
                  metrics=['accuracy'])
    target = y_test

    model.fit(X_train,y_train,epochs=10,batch_size=10,verbose=0)

    predict= model.predict(X_test)

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(predict)):
            if target[i] == c and predict[i] == c:
                tp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if (target[i] == c and predict[i] != c):
                fn += 1
            if (target[i] != c and predict[i] == c):
                fp += 1


    Acc = (tp + tn) / (tp + tn + fp + fn)
    sen = tp / (tp + fn)

    ACC.append(Acc)
    SEN.append(sen)





