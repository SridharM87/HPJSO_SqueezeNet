import random,math
import numpy as np


def algm():
    def generate(n, m, l, u):   #Generated solution
        data = []
        for i in range(n):
            tem = []
            for j in range(m):
                tem.append(random.uniform(l, u))
            data.append(tem)
        return data

    N, M, lb, ub = 10, 5, 1, 5
    g, max = 0, 100

    soln = generate(N, M, lb, ub)

    def fitness(soln):
        F = []
        for i in range(len(soln)):
            F.append(random.random())
        return F
    def opt_current(Iph,Id):
        Io=[]
        for i in range(len(Iph)):
            for j in range(len(Iph[i])):
                Io.append(Iph[i][j]-Id[j])
        return Io

    def reverse_sat_current(Istc):
        Io=[]
        T=100 # Absolute temperature
        q=1.6*(10^-19) # Electron charge
        k=1.38*(10^-23)
        for i in range(len(Istc)):
            Io.append(Istc[i]*(np.square(T/T))*np.exp(q/k))
        return Io
    def ocean_current(x):
        Drift=[]
        N=len(x)
        mu=np.mean(x)
        Beta=3  # Distribution coefficient
        ac=5  # Attractive coefficient
        for i in range(len(x)):
            Drift.append((1/N)*np.sum(x[i]-ac))
        Xi=[]
        for j in range(len(x)):
            c=2*random.random()
            z=random.random()
            R=2

            Xi.append((x[j]*(1+c*z*np.cos(2*np.pi*R*4))+(random.uniform(0,1)*x[j]-Beta*random.uniform(0,1)*mu)*(c*z*np.cos(2*np.pi*R*4)))/(c*z*np.cos(2*np.pi*R*4)+1))  # update equation
        return Xi

    while g<max:
        Fit=fitness(soln)
        Op_c=opt_current(soln,Fit)
        Ist=reverse_sat_current(Op_c)
        upd_soln=ocean_current(Ist)

        g += 1

    return np.max(upd_soln)

