import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from sklearn.model_selection import train_test_split  # Import train_test_split function
import numpy as np,cv2



def Classify(Seg_Img,target,tr,ACC,SEN):
    array = []
    for i in range(len(Seg_Img)):
        read = cv2.imread(Seg_Img[i])

        array_ = [i for i in range(len(read))]
        array.append(array_)

    X_train, X_test, y_train, y_test = train_test_split(array, target, train_size=tr, random_state=42)

    batch_size = 64
    epochs = 20
    num_classes = 10


    xt=len(X_test)

    model = Sequential()
    model.add(Conv2D(32, kernel_size=(3, 3), activation='linear', input_shape=(28, 28, 1), padding='same'))
    #model.add(LeakyReLU(alpha=0.1))
    model.add(MaxPooling2D((2, 2), padding='same'))
    model.add(Conv2D(64, (3, 3), activation='linear', padding='same'))
    #model.add(LeakyReLU(alpha=0.1))
    model.add(MaxPooling2D(pool_size=(2, 2), padding='same'))
    model.add(Conv2D(128, (3, 3), activation='linear', padding='same'))
    #model.add(LeakyReLU(alpha=0.1))
    model.add(MaxPooling2D(pool_size=(2, 2), padding='same'))
    model.add(Flatten())
    model.add(Dense(128, activation='linear'))
    #model.add(LeakyReLU(alpha=0.1))
    model.add(Dense(num_classes, activation='softmax'))
    X_test = np.resize(X_test, (xt, 28, 28, 1))
    model.compile(loss=keras.losses.categorical_crossentropy, optimizer='Adam',
                          metrics=['accuracy'])
    predict = model.predict(X_test)


    target = y_test

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(target)):
            if target[i] == c and predict[i] == c:
                fp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if (target[i] == c and predict[i] != c):
                tp += 1
            if (target[i] != c and predict[i] == c):
                fn += 1



    Acc = (tp + tn) / (tp + tn + fp + fn)
    sen = tp / (tp + fn)

    ACC.append(Acc)
    SEN.append(sen)