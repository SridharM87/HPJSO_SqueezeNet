import tensorflow as tf
sourceWidth=228
sourceHeight=228
sourceChannels=1
num_classes=2
# INPUT LAYER #
inputL = tf.keras.layers.Input((sourceWidth, sourceHeight, sourceChannels))

#inputL = tf.keras.layers.ResNet50()

# ENCODER #
conv1 = tf.keras.layers.Conv2D(32, (3,3), activation='relu', padding='same')(inputL)
conv1 = tf.keras.layers.Dropout(0.1)(conv1)
conv1 = tf.keras.layers.Conv2D(32, (3,3), activation='relu', padding='same')(conv1)
conv1 = tf.keras.layers.MaxPooling2D((2,2))(conv1)

conv2 = tf.keras.layers.Conv2D(64, (3,3), activation='relu', padding='same')(conv1)
conv2 = tf.keras.layers.Dropout(0.1)(conv2)
conv2 = tf.keras.layers.Conv2D(64, (3,3), activation='relu', padding='same')(conv2)
conv2 = tf.keras.layers.MaxPooling2D((2,2))(conv2)

conv3 = tf.keras.layers.Conv2D(128, (3,3), dilation_rate=(2,2), activation='relu', padding='same')(conv2)
conv3 = tf.keras.layers.Dropout(0.1)(conv3)
conv3 = tf.keras.layers.Conv2D(128, (3,3), dilation_rate=(2,2), activation='relu', padding='same')(conv3)
conv3 = tf.keras.layers.MaxPooling2D((2,2))(conv3)

conv4 = tf.keras.layers.Conv2D(256, (3,3), dilation_rate=(4,4), activation='relu', padding='same')(conv3)
conv4 = tf.keras.layers.Dropout(0.1)(conv4)
conv4 = tf.keras.layers.Conv2D(256, (3,3), dilation_rate=(4,4), activation='relu', padding='same')(conv4)


# PYRAMID POOLING MODULE
# Pyramid block 1 #
pyramid_block1 = tf.keras.layers.GlobalAveragePooling2D()(conv4)
pyramid_block1 = tf.keras.layers.Reshape((1,1,1,256))(pyramid_block1)
pyramid_block1 = tf.keras.layers.ConvLSTM2D(64, (1,1), strides=(1,1), activation='relu')(pyramid_block1)
pyramid_block1 = tf.keras.layers.Conv2DTranspose(64, (1,1), strides=(36,36), padding='same')(pyramid_block1)

# Pyramid block 2 #
pyramid_block2 = tf.keras.layers.AveragePooling2D(pool_size=(18,18), strides=(18,18))(conv4)
pyramid_block2 = tf.keras.layers.Reshape((1,1,1,256))(pyramid_block2)
pyramid_block2 = tf.keras.layers.ConvLSTM2D(64, (1,1), strides=(1,1), activation='relu')(pyramid_block2)
pyramid_block2 = tf.keras.layers.Conv2DTranspose(64, (2,2), strides=(18,18), padding='same')(pyramid_block2)

# Pyramid block 3 #
pyramid_block3 = tf.keras.layers.AveragePooling2D(pool_size=(9,9), strides=(9,9))(conv4)
pyramid_block3 = tf.keras.layers.Conv2D(64, (1,1), strides=(1,1), activation='relu')(pyramid_block3)
pyramid_block3 = tf.keras.layers.Conv2DTranspose(64, (3,3), strides=(9,9), padding='same')(pyramid_block3)

# Pyramid block 4 #
pyramid_block4 = tf.keras.layers.AveragePooling2D(pool_size=(6,6), strides=(6,6))(conv4)
pyramid_block4 = tf.keras.layers.Conv2D(64, (1,1), strides=(1,1), activation='relu')(pyramid_block4)
pyramid_block4 = tf.keras.layers.Conv2DTranspose(64, (2,2), strides=(6,6), padding='same')(pyramid_block4)

# DECODER
#pyramid = tf.keras.layers.concatenate([pyramid_block4, pyramid_block3, pyramid_block2, pyramid_block1])
conv7 = tf.keras.layers.Conv2D(64, (3,3), strides=(1,1), activation='relu', padding='same')(pyramid_block1)
conv7 = tf.keras.layers.Dropout(0.2)(conv7)
conv7 = tf.keras.layers.Conv2D(64, (3,3), strides=(1,1), activation='relu', padding='same')(conv7)

conv8 = tf.keras.layers.Conv2DTranspose(64, (2,2), strides=(8,8), padding='same')(conv7)
conv8 = tf.keras.layers.Conv2D(32, (3,3), strides=(1,1), activation='relu', padding='same')(conv8)
conv8 = tf.keras.layers.Dropout(0.2)(conv8)
conv8 = tf.keras.layers.Conv2D(32, (3,3), strides=(1,1), activation='relu', padding='same')(conv8)
output = tf.keras.layers.Conv2D(num_classes, (1,1), activation='softmax')(conv8)

model = tf.keras.Model(inputs=[inputL], outputs=[output])
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()
tf.keras.utils.plot_model(model, to_file='Psi_net.png', show_shapes=True, show_layer_names=True)

model.save('psi_net.h5')