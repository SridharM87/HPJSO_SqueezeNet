import read
import cv2

path1='Processed/Preprocessed_Img/*'
IMG1=read.image(path1)
path2='Processed/segmented_Img/*'
IMG2=read.image(path2)


for i in range(len(IMG1)):
    print("i :",i)
    img1=cv2.imread(IMG1[i])
    img2=cv2.imread(IMG2[i])

    img=img1*img2
    cv2.imwrite("Processed/Seg_Img/"+str(i)+".jpg",img)

