import numpy, random
import Proposed_HPJSO.run
import sys
import read
import Preprocessing
import pandas as pd
import numpy as np
import Proposed_HPJSO_Squeezenet.DCNN
import Proposed_HPJSO_Squeezenet.Squeezenet_Testing


def  phase(rounds, nodes,tr,ACC,SEN):
    pop_size = 5
    # parameter initialization
    n_cluster = 5  # no. of cluster
    n_nodes = nodes + 1  # no. of nodes(+base station)
    BASE_STATION = n_nodes - 1  # base station -- last node

    # to place nodes over grid
    sq = int(numpy.sqrt(n_nodes))  # to make the nodes in square grid -- take sqrt of nodes
    ex = n_nodes % sq  # excess nodes when make it square grid
    col_n = int((n_nodes - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  # last column with excess nodes
    m.append(ex)

    # creating nodes
    def node_creation(x_value, y_value):
        Input_leaf_Img='Dataset/*/*'
        IMG = read.image(Input_leaf_Img)

        for x in range(col_n + 1):  # x columns1
            for y in range(m[x]):  # y rows
                px = 50 + x * 60 + random.uniform(-20, 20)  # node in x-axis at px
                x_value.append(px)
                py = 50 + y * 60 + random.uniform(-20, 20)  # node in y-axis at py
                y_value.append(py)
        return IMG

    # initial energy generation
    def generate(v):
        data = []
        for i in range(nodes):
            data.append(v)  # initial energy of all nodes is 1
        return data

    # packets to be send by each node
    def node_packet(nod):
        dp = []
        for i in range(rounds):
            tem = []
            for j in range(nod):
                tem.append(random.randint(1, 10))
            dp.append(tem)
        return dp
    def check(Data):
        b = []
        for i in range(len(Data)):
            c = Data[i]
            c.sort()
            b.append(c)
        return b

    def view_bar(job_title, progress):
        length = 20  # modify this to change the length
        block = int(round(length * progress))
        msg = "\r{0}: [{1}] {2}%".format(job_title, "#" * block + "-" * (length - block), round(progress * 100, 2))
        if progress >= 1: msg += " DONE\r\n"
        sys.stdout.write(msg)
        sys.stdout.flush()

    print("\nSystem model..")
    data_packet = node_packet(nodes)  # packets send by each node
    Xt, Xr = 0.0035, 0.0035 # energy required to send, receive data
    Final_Throughput, Final_Energy, Final_Delay,Final_dis = [], [], [] ,[]      # Final energy,... of the nodes after all rounds
    Overall_Throughput, Overall_Energy, Overall_Delay,Overall_dis = [], [], [],[] # each round energy,... of all methods
    ################################################## Proposed_HPJSO_Squeezenet HPJSO#############################################
    Throughput, Energy, Delay = [], [], []
    Throughput_avg, Energy_avg, Delay_avg, Dis_avg = [], [], [], []
    print("\t>> Energy model..")
    Throughput.append(generate(0))
    Energy.append(generate(1))
    Delay.append(generate(0))
    sr = []
    print("\t>> Mobility model..")
    print("\nCluster Head selection ....Please wait....")
    for i in range(rounds):
        print("rounds :",i)
        view_bar("Selection Onprogress", i / (rounds - 1))
        x_value, y_value = [], []  # x & y value of each node
        Img=node_creation(x_value, y_value)


        tp, en, de, dis = Proposed_HPJSO.run.func(rounds, nodes, n_cluster, Energy[i], Delay[i], data_packet[i],
                                                   x_value, y_value, BASE_STATION, i, pop_size, Xt, Xr, col_n, sr,
                                                   Throughput[i])


        Preprocessing.Images(Img)  # Preprocessing by using Gaussian filter

        seg_img = 'Processed/Seg_Img/*'  # The preprocessed Image is segmented and stored along this path
        Seg_IMG = read.image(seg_img)

        Label1 = pd.read_csv("Processed/Label1.csv", header=None)  # For Plant type
        Label1 = np.array(Label1)

        Label2 = pd.read_csv("Processed/Label2.csv", header=None)  # For Plant Disease
        Label2 = np.array(Label2)
        # -----------first level classification ------------------
        Proposed_HPJSO_Squeezenet.DCNN.Classify(Seg_IMG, Label1, tr, ACC, SEN)

        # -----------Second level Classification------------
        Proposed_HPJSO_Squeezenet.Squeezenet_Testing.Classify(Seg_IMG, Label2, tr, ACC, SEN)


        Throughput.append(tp)
        Energy.append(en)
        Delay.append(de)


        Throughput_avg.append(numpy.average(tp))
        Energy_avg.append(numpy.average(en))
        Delay_avg.append(numpy.average(de))
        Dis_avg.append(numpy.min(dis))


    Final_Throughput.append(Throughput_avg[rounds-1]), Final_Delay.append(Delay_avg[rounds-1]), Final_Energy.append(Energy_avg[rounds-1]), Final_dis.append(Dis_avg[rounds-1])
    Overall_Throughput.append(Throughput_avg), Overall_Energy.append(Energy_avg), Overall_Delay.append(Delay_avg)
    Overall_dis.append(Dis_avg)


    return Final_Throughput, Final_Energy,Final_Delay, Final_dis,sr




