
import Routing


def callmain(nodes,tr):
    ACC,SEN=[],[]


    rounds=2000

    T, E, De, Dis,SR = Routing.phase(rounds, nodes,tr,ACC,SEN)


    return E,T,De,Dis,ACC,SEN,SR

