
from PSI_Segmentation.data_generator import *




def mask_to_3d(mask):
    mask = np.squeeze(mask)
    mask = [mask, mask, mask]
    mask = np.transpose(mask)
    return mask
if __name__ == "__main__":
    ## Path
    file_path = "files/"
    model_path = "PSI_Segmentation/psi_net.h5"

    ## Create files folder
    try:
        os.mkdir("files")
    except:
        pass

    import read

    ## Training
    train_image_p = "Processed/Preprocessed_Img/*"
    train_image_paths=read.image(train_image_p)
    train_mask_p = "Processed/gt/*"
    train_mask_paths=read.image(train_mask_p)


    # train_image_paths = train_image_paths[:2000]
    # train_mask_paths = train_mask_paths[:2000]

    ## Validation
    valid_image_p = "Processed/Preprocessed_Img/*"
    valid_image_paths=read.image(valid_image_p)
    valid_mask_p = "Processed/gt/*"
    valid_mask_paths=read.image(valid_mask_p)



    ## Parameters
    image_size = 256
    batch_size = 8
    lr = 1e-4
    epochs = 500

    train_steps = len(train_image_paths)//batch_size
    valid_steps = len(valid_image_paths)//batch_size

    ## Generator
    train_gen = DataGen(image_size, train_image_paths, train_mask_paths, batch_size=batch_size)
    valid_gen = DataGen(image_size, valid_image_paths, valid_mask_paths, batch_size=batch_size)

    from tqdm import tqdm
    from tensorflow import keras

    #--------testing-------------------
    model = keras.models.load_model(model_path)


    save_path = "Processed/segmented_Img"

    test_mask_p = "Processed/gt/*"
    test_mask_paths = read.image(test_mask_p)

    test_image_p = "Processed/Preprocessed_Img/*"
    test_image_paths = read.image(test_image_p)
    ## Generating the result
    for i, path in tqdm(enumerate(test_image_paths), total=len(test_image_paths)):
        print("i :",i)
        image = parse_image(test_image_paths[i], image_size)
        mask = parse_mask(test_mask_paths[i], image_size)
        print("image shape :",image.shape)
        image=np.resize(image,(228,228,1))
        predict_mask = model.predict(np.expand_dims(image, axis=0))[0]
        predict_mask = (predict_mask > 0.5) * 255.0

        sep_line = np.ones((image_size, 10, 3)) * 255

        mask = mask_to_3d(mask)
        predict_mask = mask_to_3d(predict_mask)
        #
        all_images = [image * 255, sep_line, mask * 255, sep_line, predict_mask]


        predict_mask=np.resize(predict_mask,(256,256,3))
        cv2.imwrite(f"{save_path}/{i}.jpg", predict_mask)




    print("Test image generation complete")
