import cv2,read
import matplotlib.pyplot as plt
path='Dataset/*/*'
IMG=read.image(path)

from collections import Counter
def get_most_dominant_border_color(img):
    # Get the top row
    row_1 = img[0, :]
    # Get the left-most column
    col_1 = img[:, 0]
    # Get the bottom row
    row_2 = img[-1, :]
    # Get the right-most column
    col_2 = img[:, -1]

    combined_li = row_1.tolist() + row_2.tolist() + col_1.tolist() + col_2.tolist()

    color_counter = Counter(combined_li)

    return max(color_counter.keys())

for i in range(len(IMG)):
    print("i :",i)

    img = cv2.imread(IMG[i],0)

    ret, thresh = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    plt.imshow(thresh,cmap='gray')
    plt.show()
    val=get_most_dominant_border_color(thresh)
    print("val :",val)

    #cv2.imwrite("Processed/gt/"+str(i)+".jpg",thresh)