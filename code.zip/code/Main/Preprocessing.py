import read
import cv2


def pre(path):
    IMG=read.image(path)


    for i in range(len(IMG)):

        print("i :",i)

        img=cv2.imread(IMG[i])

        # apply guassian blur on src image
        dst = cv2.GaussianBlur(img, (5, 5), cv2.BORDER_DEFAULT)

        cv2.imwrite("Processed/Preprocessed_Img/"+str(i)+".jpg",dst)

def Images(path):

    #pre(path)
    pre_image_path="Processed/Preprocessed_Img/*"
    Pre_Img=read.image(pre_image_path)

    return Pre_Img