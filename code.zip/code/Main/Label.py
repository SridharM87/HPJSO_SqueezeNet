import read
import numpy as np
path='Dataset/*/*'

IMG=read.image(path)

#--------------------plant type ---------------------

def Label_planttype():
    Label1=[]
    for i in range(len(IMG)):
        img=IMG[i]
        img=img.split('\\')
        img=img[1].split('_')

        if img[0]=='Apple':
            Label1.append(0)
        if img[0] == 'Cherry':
            Label1.append(1)
        if img[0]=='Corn':
            Label1.append(2)
        if img[0] == 'Grape':
            Label1.append(3)
        if img[0]=='Potato':
            Label1.append(4)
        if img[0] == 'Strawberry':
            Label1.append(5)
        if img[0]=='Tomato':
            Label1.append(6)
    print("Labeee l :", Label1)
    print("Labeee l :", len(Label1))
    np.savetxt("Processed/Label1.csv",Label1,delimiter=',',fmt='%s')
    return Label1


#Label_planttype()


#----------------plant disese--------------------

def Label_plant_disease():
    Label2 = []
    temp=[]
    for i in range(len(IMG)):
        img = IMG[i]
        img=img.split('\\')
        img=img[1].split('__')
        temp.append(img[1])
    uni=np.unique(temp)
    uni=np.array(uni).tolist()
    uni.sort(reverse=True)


    for i in range(len(temp)):

        for j in range(len(uni)):

            if temp[i]==uni[j]:
                Label2.append(j)


    print("tempp  :",temp)
    print("uniiiiiiii :",uni)
    print("imggg :",Label2)
    print("imggg :",len(Label2))
    np.savetxt("Processed/Label2.csv",Label2,delimiter=',',fmt='%s')
    return Label2


#Label_plant_disease()